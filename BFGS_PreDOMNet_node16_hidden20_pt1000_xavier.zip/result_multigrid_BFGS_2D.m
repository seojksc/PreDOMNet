
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all

node = [16];

hidden = [20]; 

for h_ = 1:length(hidden)
for k_node = 1:length(node)
    iter_error = [];
    iter_error_multi = [];
    for i_loop = 1:1
        perm_ = randperm(node(k_node)+1);
        w0 = load('w_H50');
        v0 = load('v_H50');
        w = w0.w;
        v = v0.v;
        w = w(1:20,:);
        v = v(1:20);

        w = 2/sqrt(3)*(10*w - 0.5);
        v = 2/sqrt(20)*(10*v - 0.5);        
        
        [iter_total,time_total,loss_total,l2_err,h1_err] = fem1dim_opt11_ann5_multigrid_BFGS23(node(k_node),hidden(h_),10^(-10),0.00001,w,v);         
        
    end
end

end


return







